The Windows version of TestDisk & PhotoRec should work under
- Windows NT 4
- Windows 2000
- Windows XP
- Windows 2003
- Windows Vista
- Windows Server 2008
- Windows 7
On Windows 64-bit, WoW64 (Windows 32-bit On Windows 64-bit) is required to run
these 32-bit executables.
For Windows 64-bit without WoW64, use the Windows 64-bit version of TestDisk
& PhotoRec.

If you are using an older version of Windows, run the DOS version of TestDisk.
You can download it from https://www.cgsecurity.org/wiki/TestDisk_Download

TestDisk doesn't need to be installed, you only need to
- extract the files
- run testdisk_win.exe or photorec_win.exe

TestDisk & PhotoRec documentation can be found online:
- https://www.cgsecurity.org/wiki/TestDisk
- https://www.cgsecurity.org/wiki/PhotoRec
